﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DateandTime : MonoBehaviour {

    int Month;
    public int Year;
    public float MonthTick;
    public float TickRate  = 2;
    public Text textYear;
    public Text textMonth;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        MonthTick += Time.deltaTime * TickRate;

        Month = (int)Mathf.Floor(MonthTick);

        if(Month >12)
        {
            Month = 1;
            MonthTick = 1;
            Year += 1;
        }
        if(Month < 1)
        {
            Month = 1;
            MonthTick = 1;
        }
        textYear.text = Year.ToString();
        switch(Month)
        {
            case 1:
                {
                    textMonth.text = "January";
                }
                break;
            case 2:
                {
                    textMonth.text = "Feburary";
                }
                break;
            case 3:
                {
                    textMonth.text = "March";
                }
                break;
            case 4:
                {
                    textMonth.text = "April";
                }
                break;
            case 5:
                {
                    textMonth.text = "May";
                }
                break;
            case 6:
                {
                    textMonth.text = "June";
                }
                break;
            case 7:
                {
                    textMonth.text = "July";
                }
                break;
            case 8:
                {
                    textMonth.text = "August";
                }
                break;
            case 9:
                {
                    textMonth.text = "September";
                }
                break;
            case 10:
                {
                    textMonth.text = "October";
                }
                break;
            case 11:
                {
                    textMonth.text = "November";
                }
                break;
            case 12:
                {
                    textMonth.text = "December";
                }
                break;
        }
        textYear.text = Year.ToString();
	}


}
