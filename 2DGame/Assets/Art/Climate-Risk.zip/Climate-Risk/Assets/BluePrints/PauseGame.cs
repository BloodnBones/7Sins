﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class PauseGame : MonoBehaviour {



    bool isOver;
    bool paused;

	// Use this for initialization
	void Start () {
        gameObject.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void Pause()
    {
        Time.timeScale = 0f;

        gameObject.SetActive(true);

    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isOver = true;
        Debug.Log("drh");
    }

    public void Unpause()
    {
        Time.timeScale = 1f;

        gameObject.SetActive(false);
    }

    public void Quit()
    {
        Application.Quit();
    }
}
