﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class UIManager : MonoBehaviour
{
    // ScoreManager score_manager;

    //public Text score_text;
    //   public Text books_text;

    void Start()
    {

    }

    void Update()
    {
        //SetScoreText();
        //      SetBooksDroppedText();
    }

    //void SetScoreText()
    //{
    //       if (score_text != null)
    //       {
    //           score_text.text = ScoreManager.score.ToString();
    //       }
    //   }

    //   void SetBooksDroppedText()
    //   {
    //       if (books_text != null)
    //       {
    //           books_text.text = PlayerBookDrop.totalBooks.ToString();
    //       }
    //   }

    //loads inputted level
    public void LoadLevel(string level)
    {
        SceneManager.LoadScene(level);
    }

    // Quits the Game
    public void QuitGame()
    {
        Application.Quit();
    }
}