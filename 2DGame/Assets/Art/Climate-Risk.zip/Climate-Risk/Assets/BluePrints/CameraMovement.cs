﻿using UnityEngine;
using System.Collections;

public class CameraMovement : MonoBehaviour {

    public float ScrollSpeed = 15;
    public float ScrollEdge = 0.01f;

    private float mouseX;

 
    float PanSpeed = 10.0f;
 
    Vector2 ZoomRange;

    float CurrentZoom = 0;
    float ZoomZpeed = 10.0f;
    float ZoomRotation = 1;
 
private Vector3 InitPos;
private Vector3 InitRotation;
 
 
 
    void Start()
    {
        //Instantiate(Arrow, Vector3.zero, Quaternion.identity);
        ZoomRange.x = -5;
        ZoomRange.y = 5;
        InitPos = transform.position;
        InitRotation = transform.eulerAngles;

    }

  
    void Update()
    {
      
       

        //ZOOM IN/OUT

      //  CurrentZoom -= Input.GetAxis("Mouse ScrollWheel") * Time.deltaTime * 1000 * ZoomZpeed;

        //CurrentZoom = Mathf.Clamp(CurrentZoom, ZoomRange.x, ZoomRange.y);

        //transform.position.y -= (transform.position.y - (InitPos.y + CurrentZoom)) * 0.1f;
        //transform.eulerAngles.x -= (transform.eulerAngles.x - (InitRotation.x + CurrentZoom * ZoomRotation)) * 0.1f;

       

    }
}
