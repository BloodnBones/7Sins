﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{

    public float ScrollSpeed = 15;
    public float ScrollEdge = 0.01f;

    private float mouseX;

    bool CameraMove = true;
    float PanSpeed = 10.0f;

    Vector2 ZoomRange;

    float CurrentZoom = 0;
    float ZoomZpeed = 10.0f;
    float ZoomRotation = 1;

    private Vector3 InitPos;
    private Vector3 InitRotation;

    // Use this for initialization
    void Start()
    {

    }


    void MouseRotation()
    {
        var easeFactor = 10f;
        if (Input.GetMouseButton(1))
        {
            CameraMove = false;
            if (Input.mousePosition.x != mouseX)
            {
                Vector3 Rotationaxis = new Vector3(0, 1, 0);
                var cameraRotationY = (Input.mousePosition.x - mouseX) * easeFactor * Time.deltaTime;
                this.transform.RotateAround(this.transform.position, Rotationaxis, cameraRotationY);
            }
        }else
        {
            CameraMove = true;
        }
    }
    // Update is called once per frame
    void Update()
    {
        MouseRotation();

        if(CameraMove)
        {
            if (Input.GetKey("d") || Input.mousePosition.x >= Screen.width * (1 - ScrollEdge))
            {
                transform.Translate(Vector3.right * Time.deltaTime * ScrollSpeed, Space.Self);
            }
            else if (Input.GetKey("a") || Input.mousePosition.x <= Screen.width * ScrollEdge)
            {
                transform.Translate(Vector3.right * Time.deltaTime * -ScrollSpeed, Space.Self);
            }

            if (Input.GetKey("w") || Input.mousePosition.y >= Screen.height * (1 - ScrollEdge))
            {
                transform.Translate(Vector3.forward * Time.deltaTime * ScrollSpeed, Space.Self);
            }
            else if (Input.GetKey("s") || Input.mousePosition.y <= Screen.height * ScrollEdge)
            {
                transform.Translate(Vector3.forward * Time.deltaTime * -ScrollSpeed, Space.Self);
            }

           
            //PAN
        }
        mouseX = Input.mousePosition.x;
    }
}